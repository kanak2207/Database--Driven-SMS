# Experiment 8 — Database-Driven Student Management System

**Student:** KANAK TIWARI  
**Roll No.:** 23BCOL2259

A student management dashboard built with Node.js, Express.js, MongoDB (Mongoose), REST APIs, filtering, pagination and aggregation-based analytics.

## Features
- Student CRUD: create, read, update and delete
- Search by student name, ID, email or department
- Filter by department, semester and status
- Server-side pagination
- Dashboard analytics: total students, average CGPA, average attendance, at-risk count and department breakdown
- MongoDB aggregation pipeline for dashboard statistics
- Responsive pastel dashboard UI
- JSON demo mode for quick testing when MongoDB is not configured

## Requirements
- Node.js 18 or newer
- npm
- MongoDB Atlas account or local MongoDB (optional for demo mode)

## Run in demo mode (no MongoDB setup)
1. Extract the ZIP.
2. Open the extracted project folder.
3. Click the File Explorer address bar, type `cmd`, and press Enter.
4. Run:

```bash
npm install
npm start
```

5. Open http://localhost:3000

The demo uses `data/students.json` and persists changes there. This mode is provided for immediate UI/API testing.

## Connect MongoDB Atlas
1. In MongoDB Atlas, open **Database & Network Access → Database Users** and create or reset a database user's password. This is the database password, not your Atlas login password.
2. Under **Network Access → IP Access List**, add your current IP address. For a temporary classroom test, Atlas may offer `0.0.0.0/0`; this allows access from any IP, so remove it after testing.
3. Go to **Database → Clusters → Connect → Drivers → Node.js** and copy the connection string.
4. In the project folder, create `.env` by copying `.env.example`:

Windows CMD:
```cmd
copy .env.example .env
notepad .env
```

5. Set `MONGODB_URI` to your Atlas URI. Replace `<db_password>` with the database user's password. If the password contains special characters such as `@`, `#`, `/`, `:`, or `%`, URL-encode them first. Do not add two `MONGODB_URI` lines.
6. Save `.env`, then run `npm start`. The terminal should say `Connected to MongoDB`.

Example shape (use your own host and credentials):
```env
PORT=3000
NODE_ENV=development
MONGODB_URI=mongodb+srv://DB_USER:URL_ENCODED_PASSWORD@cluster0.example.mongodb.net/student_management?retryWrites=true&w=majority
```

**Security:** Never share your real database password or commit `.env`. If credentials were posted publicly, reset the database user's password in Atlas.

## REST API endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | API/database status |
| GET | `/api/students` | List students; supports `page`, `limit`, `q`, `department`, `semester`, `status` |
| GET | `/api/students/:id` | Get one student by MongoDB `_id` or demo `studentId` |
| POST | `/api/students` | Create student |
| PUT | `/api/students/:id` | Update student |
| DELETE | `/api/students/:id` | Delete student |
| GET | `/api/analytics` | Aggregated dashboard statistics |
| GET | `/api/departments` | Department list |

### Example POST body
```json
{
  "studentId": "STU1010",
  "name": "Aditi Rao",
  "email": "aditi@example.com",
  "department": "Computer Science",
  "semester": 3,
  "cgpa": 8.6,
  "attendance": 91,
  "status": "Active"
}
```

### Example queries
- `GET http://localhost:3000/api/students?page=1&limit=5`
- `GET http://localhost:3000/api/students?q=Meera`
- `GET http://localhost:3000/api/students?department=Electronics&semester=6`
- `GET http://localhost:3000/api/analytics`

## Postman testing
1. Open Postman.
2. Select **Import**.
3. Import `postman/Question_8_Student_Management.postman_collection.json`.
4. Start the server at port 3000.
5. Run requests in order. The collection includes health, list, analytics, create, get, update and delete examples.

## Architecture / workflow
Administrator dashboard → Express REST API → MongoDB student records and aggregation pipeline → JSON API responses → dashboard tables and analytics.

## Submission note
For the database-driven demonstration, connect MongoDB Atlas using the steps above before taking screenshots of the final run. The app can also be launched in local JSON demo mode for a quick preview.
