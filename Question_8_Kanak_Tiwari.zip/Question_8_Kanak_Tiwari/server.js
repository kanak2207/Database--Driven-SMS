require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "data", "students.json");
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const studentSchema = new mongoose.Schema({
  studentId: { type: String, required: true, unique: true, trim: true },
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, trim: true, lowercase: true },
  department: { type: String, required: true, trim: true },
  semester: { type: Number, required: true, min: 1, max: 12 },
  cgpa: { type: Number, required: true, min: 0, max: 10 },
  attendance: { type: Number, required: true, min: 0, max: 100 },
  status: { type: String, enum: ["Active", "At Risk"], default: "Active" }
}, { timestamps: true });
const Student = mongoose.model("Student", studentSchema);

let mongoReady = false;
let localStudents = [];
function loadLocal() {
  try { localStudents = JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { localStudents = []; }
}
function saveLocal() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(localStudents, null, 2));
}
function validate(body) {
  const required = ["studentId","name","email","department","semester","cgpa","attendance"];
  for (const key of required) if (body[key] === undefined || String(body[key]).trim() === "") return `${key} is required`;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) return "Enter a valid email address";
  if (+body.semester < 1 || +body.semester > 12) return "Semester must be between 1 and 12";
  if (+body.cgpa < 0 || +body.cgpa > 10) return "CGPA must be between 0 and 10";
  if (+body.attendance < 0 || +body.attendance > 100) return "Attendance must be between 0 and 100";
  return null;
}
function normalized(body) {
  return { studentId:String(body.studentId).trim(), name:String(body.name).trim(),
    email:String(body.email).trim().toLowerCase(), department:String(body.department).trim(),
    semester:Number(body.semester), cgpa:Number(body.cgpa), attendance:Number(body.attendance),
    status: body.status || (Number(body.attendance) < 75 || Number(body.cgpa) < 6 ? "At Risk" : "Active") };
}
function matchesFilters(s, q, department, semester, status) {
  const search = (q || "").toLowerCase();
  return (!search || [s.name,s.studentId,s.email,s.department].some(v => String(v).toLowerCase().includes(search))) &&
    (!department || s.department === department) &&
    (!semester || Number(s.semester) === Number(semester)) &&
    (!status || s.status === status);
}
async function getStudents() { return mongoReady ? Student.find().lean() : localStudents; }

app.get("/api/health", (req,res) => res.json({success:true, database:mongoReady ? "MongoDB" : "Local JSON demo", status:"ready"}));

app.get("/api/students", async (req,res,next) => {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 8));
    const { q="", department="", semester="", status="" } = req.query;
    let rows, total;
    if (mongoReady) {
      const filter = {};
      if (q) filter.$or = ["name","studentId","email","department"].map(k => ({[k]:{$regex:q,$options:"i"}}));
      if (department) filter.department = department;
      if (semester) filter.semester = Number(semester);
      if (status) filter.status = status;
      total = await Student.countDocuments(filter);
      rows = await Student.find(filter).sort({createdAt:-1}).skip((page-1)*limit).limit(limit).lean();
    } else {
      const filtered = localStudents.filter(s => matchesFilters(s,q,department,semester,status));
      total = filtered.length;
      rows = filtered.slice((page-1)*limit,page*limit);
    }
    res.json({success:true,data:rows,pagination:{page,limit,total,totalPages:Math.ceil(total/limit)}});
  } catch(e) { next(e); }
});

app.post("/api/students", async (req,res,next) => {
  try {
    const error = validate(req.body); if (error) return res.status(400).json({success:false,message:error});
    const item = normalized(req.body);
    if (mongoReady) {
      const created = await Student.create(item);
      return res.status(201).json({success:true,data:created});
    }
    if (localStudents.some(s => s.studentId === item.studentId || s.email === item.email))
      return res.status(409).json({success:false,message:"Student ID or email already exists"});
    localStudents.unshift(item); saveLocal();
    res.status(201).json({success:true,data:item});
  } catch(e) { if (e.code === 11000) return res.status(409).json({success:false,message:"Student ID or email already exists"}); next(e); }
});

app.get("/api/students/:id", async (req,res,next) => {
  try {
    const item = mongoReady ? await Student.findById(req.params.id).lean() : localStudents.find(s => s.studentId === req.params.id);
    if (!item) return res.status(404).json({success:false,message:"Student not found"});
    res.json({success:true,data:item});
  } catch(e) { next(e); }
});

app.put("/api/students/:id", async (req,res,next) => {
  try {
    const error = validate(req.body); if (error) return res.status(400).json({success:false,message:error});
    const item = normalized(req.body);
    let updated;
    if (mongoReady) updated = await Student.findByIdAndUpdate(req.params.id,item,{new:true,runValidators:true});
    else {
      const index = localStudents.findIndex(s => s.studentId === req.params.id);
      if (index >= 0) { localStudents[index] = item; saveLocal(); updated = item; }
    }
    if (!updated) return res.status(404).json({success:false,message:"Student not found"});
    res.json({success:true,data:updated});
  } catch(e) { next(e); }
});

app.delete("/api/students/:id", async (req,res,next) => {
  try {
    let deleted;
    if (mongoReady) deleted = await Student.findByIdAndDelete(req.params.id);
    else {
      const index = localStudents.findIndex(s => s.studentId === req.params.id);
      if (index >= 0) deleted = localStudents.splice(index,1)[0];
      if (deleted) saveLocal();
    }
    if (!deleted) return res.status(404).json({success:false,message:"Student not found"});
    res.json({success:true,message:"Student deleted successfully"});
  } catch(e) { next(e); }
});

// Dashboard analytics. MongoDB mode uses aggregation pipeline.
app.get("/api/analytics", async (req,res,next) => {
  try {
    if (mongoReady) {
      const [summary] = await Student.aggregate([
        {$group:{_id:null,total:{$sum:1},avgCgpa:{$avg:"$cgpa"},avgAttendance:{$avg:"$attendance"},
          atRisk:{$sum:{$cond:[{$eq:["$status","At Risk"]},1,0]}}}}
      ]);
      const departments = await Student.aggregate([
        {$group:{_id:"$department",count:{$sum:1},avgCgpa:{$avg:"$cgpa"}}},{$sort:{count:-1}}
      ]);
      return res.json({success:true,data:{total:summary?.total||0,avgCgpa:+(summary?.avgCgpa||0).toFixed(2),
        avgAttendance:+(summary?.avgAttendance||0).toFixed(1),atRisk:summary?.atRisk||0,departments}});
    }
    const total=localStudents.length;
    const avg=(key)=>total ? localStudents.reduce((a,s)=>a+Number(s[key]),0)/total : 0;
    const map={};
    localStudents.forEach(s=>{map[s.department] ||= { _id:s.department,count:0,cgpa:0 };map[s.department].count++;map[s.department].cgpa+=s.cgpa;});
    const departments=Object.values(map).map(d=>({_id:d._id,count:d.count,avgCgpa:+(d.cgpa/d.count).toFixed(2)})).sort((a,b)=>b.count-a.count);
    res.json({success:true,data:{total,avgCgpa:+avg("cgpa").toFixed(2),avgAttendance:+avg("attendance").toFixed(1),
      atRisk:localStudents.filter(s=>s.status==="At Risk").length,departments}});
  } catch(e) { next(e); }
});

app.get("/api/departments", async (req,res,next) => {
  try {
    const rows = mongoReady ? await Student.distinct("department") : [...new Set(localStudents.map(s=>s.department))];
    res.json({success:true,data:rows.sort()});
  } catch(e) { next(e); }
});

app.use((err,req,res,next) => {
  console.error(err);
  res.status(500).json({success:false,message:err.message || "Internal server error"});
});

async function start() {
  if (process.env.MONGODB_URI) {
    try { await mongoose.connect(process.env.MONGODB_URI); mongoReady=true; console.log("Connected to MongoDB"); }
    catch(e) { console.error("MongoDB connection failed:",e.message); console.log("Starting in local JSON demo mode instead."); loadLocal(); }
  } else { loadLocal(); console.log("MONGODB_URI not set: using local JSON demo mode."); }
  app.listen(PORT,()=>console.log(`Student Management System running at http://localhost:${PORT}`));
}
start();
