const $ = (id) => document.getElementById(id);
let page = 1, totalPages = 1, editingId = null, currentRows = [];
const initials = name => name.split(/\s+/).slice(0,2).map(x=>x[0]).join("").toUpperCase();
const esc = value => String(value ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(url, options={}) {
  const res = await fetch(url,{headers:{"Content-Type":"application/json"},...options});
  const body = await res.json();
  if(!res.ok) throw new Error(body.message || "Something went wrong");
  return body;
}
function toast(message){$("toast").textContent=message;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2600)}
async function loadHealth(){try{const r=await api("/api/health");$("dbMode").textContent=r.database+" connected"}catch{$("dbMode").textContent="API unavailable"}}
async function loadAnalytics(){
 const r=await api("/api/analytics"),d=r.data;
 $("total").textContent=d.total;$("cgpa").textContent=Number(d.avgCgpa).toFixed(2);$("attendance").textContent=Number(d.avgAttendance).toFixed(1)+"%";$("risk").textContent=d.atRisk;
 const max=Math.max(1,...d.departments.map(x=>x.count));
 $("departmentBars").innerHTML=d.departments.length?d.departments.map(x=>`<div class="bar-row"><span>${esc(x._id)}</span><div class="bar-track"><div class="bar-fill" style="width:${x.count/max*100}%"></div></div><b>${x.count}</b></div>`).join(""):'<p class="empty">No department data yet.</p>';
}
async function loadDepartments(){
 const r=await api("/api/departments");$("department").innerHTML='<option value="">All departments</option>'+r.data.map(x=>`<option>${esc(x)}</option>`).join("");
}
async function loadStudents(){
 const params=new URLSearchParams({page,limit:8,q:$("search").value,department:$("department").value,semester:$("semester").value,status:$("status").value});
 const r=await api("/api/students?"+params);currentRows=r.data;totalPages=Math.max(1,r.pagination.totalPages);
 $("recordCount").textContent=r.pagination.total;
 $("pageInfo").textContent=`Page ${page} of ${totalPages} · ${r.pagination.total} records`;
 $("prev").disabled=page<=1;$("next").disabled=page>=totalPages;
 $("studentRows").innerHTML=currentRows.length?currentRows.map(s=>`<tr>
 <td><div class="student-name"><span class="student-avatar">${esc(initials(s.name))}</span>${esc(s.name)}</div></td>
 <td class="id-text">${esc(s.studentId)}</td><td>${esc(s.department)}</td><td>${s.semester}</td><td><b>${Number(s.cgpa).toFixed(1)}</b></td><td>${s.attendance}%</td>
 <td><span class="tag ${s.status==="At Risk"?"risk":""}">${esc(s.status)}</span></td>
 <td><button class="row-actions" data-edit="${esc(s._id||s.studentId)}" title="Edit">✎</button><button class="row-actions" data-delete="${esc(s._id||s.studentId)}" title="Delete">×</button></td></tr>`).join(""):'<tr><td colspan="8" class="empty">No matching students. Try changing your filters.</td></tr>';
}
async function refresh(){try{await Promise.all([loadHealth(),loadAnalytics(),loadStudents(),loadDepartments()])}catch(e){toast(e.message)}}
function openModal(student){
 editingId=student?student._id||student.studentId:null;$("modalTitle").textContent=student?"Edit student":"Add a student";$("formError").textContent="";
 const form=$("studentForm");form.reset();
 if(student) Object.entries(student).forEach(([k,v])=>{if(form.elements[k])form.elements[k].value=v});
 $("modal").classList.add("show");
}
function closeModal(){$("modal").classList.remove("show");editingId=null}
$("addBtn").onclick=()=>openModal();$("jumpAdd").onclick=()=>openModal();$("closeModal").onclick=closeModal;$("cancelBtn").onclick=closeModal;
$("studentForm").onsubmit=async e=>{
 e.preventDefault();const body=Object.fromEntries(new FormData(e.target).entries());
 ["semester","cgpa","attendance"].forEach(k=>body[k]=Number(body[k]));
 try{
  if(editingId) await api("/api/students/"+encodeURIComponent(editingId),{method:"PUT",body:JSON.stringify(body)});
  else await api("/api/students",{method:"POST",body:JSON.stringify(body)});
  closeModal();toast(editingId?"Student updated":"Student added");await refresh();
 }catch(err){$("formError").textContent=err.message}
};
$("studentRows").addEventListener("click",async e=>{
 const edit=e.target.dataset.edit,del=e.target.dataset.delete;
 if(edit){const student=currentRows.find(s=>(s._id||s.studentId)===edit);if(student)openModal(student)}
 if(del&&confirm("Delete this student record?")){try{await api("/api/students/"+encodeURIComponent(del),{method:"DELETE"});toast("Student deleted");await refresh()}catch(err){toast(err.message)}}
});
let searchTimer; $("search").addEventListener("input",()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{page=1;loadStudents()},250)});
["department","semester","status"].forEach(id=>$(id).addEventListener("change",()=>{page=1;loadStudents()}));
$("prev").onclick=()=>{if(page>1){page--;loadStudents()}};$("next").onclick=()=>{if(page<totalPages){page++;loadStudents()}};
$("modal").addEventListener("click",e=>{if(e.target===$("modal"))closeModal()});
refresh();
